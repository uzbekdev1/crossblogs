using crossblog.Domain;

namespace crossblog.Repositories
{
    public interface ICommentRepository : IGenericRepository<Comment>
    {
    }
}