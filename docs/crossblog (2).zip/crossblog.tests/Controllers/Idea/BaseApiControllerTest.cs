﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using crossblog.Controllers;
using crossblog.Domain;
using crossblog.Dto;
using crossblog.Extensions;
using crossblog.Model;
using crossblog.Repositories;
using crossblog.tests.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace crossblog.tests.Controllers.Idea
{
    public abstract class BaseApiControllerTest
    {
        protected readonly Mock<IArticleRepository> _articlesRepositoryMock;
        protected readonly Mock<ICommentRepository> _commentsRepositoryMock;
        protected readonly ArticlesController _articlesController;
        protected readonly CommentsController _commentsController;

        protected BaseApiControllerTest()
        {

            //articles
            _articlesRepositoryMock = new Mock<IArticleRepository>();
            _articlesController = new ArticlesController(_articlesRepositoryMock.Object);

            //coments
            _commentsRepositoryMock = new Mock<ICommentRepository>();
            _commentsController = new CommentsController(_articlesRepositoryMock.Object, _commentsRepositoryMock.Object);
        }

    }
}