using System.Collections.Generic;

namespace crossblog.Model
{
    public class ArticleListModel
    {
        public IEnumerable<ArticleModel> Articles { get; set; }

        public ArticleListModel()
        {
            Articles = new ArticleModel[0];
        }
    }
}