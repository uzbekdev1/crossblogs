using System.Collections.Generic;

namespace crossblog.Model
{
    public class CommentListModel
    {
        public IEnumerable<CommentModel> Comments { get; set; }

        public CommentListModel()
        {
            Comments = new CommentModel[0];
        }
    }
}