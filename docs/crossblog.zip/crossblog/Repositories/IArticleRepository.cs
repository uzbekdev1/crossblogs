﻿using crossblog.Domain;

namespace crossblog.Repositories
{
    public interface IArticleRepository : IGenericRepository<Article>
    {
    }
}