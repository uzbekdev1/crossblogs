﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using crossblog.Domain;
using crossblog.Dto;
using crossblog.Filters;
using crossblog.Model;
using crossblog.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace crossblog.Controllers
{
    [Route("articles")]
    public class CommentsController : Controller
    {
        private readonly ICommentRepository _commentRepository;
        private readonly IArticleRepository _articleRepository;

        public CommentsController(IArticleRepository articleRepository, ICommentRepository commentRepository)
        {
            _articleRepository = articleRepository ?? throw new ArgumentNullException(nameof(articleRepository));
            _commentRepository = commentRepository ?? throw new ArgumentNullException(nameof(commentRepository));
        }

        // GET articles/5/comments
        [HttpGet("{articleId}/[controller]")]
        public async Task<IActionResult> Get([FromRoute]int? articleId)
        {
            if (articleId == null)
                return BadRequest(ApiResponse.BadRequest("Argument id is null"));

            var article = await _articleRepository.GetAsync(articleId);

            if (article == null)
                return NotFound(ApiResponse.NotFound($"Article not found with id {articleId}"));

            var result = new CommentListModel
            {
                Comments = article.Comments.Select(c => new CommentModel
                {
                    Id = c.Id,
                    Email = c.Email,
                    Title = c.Title,
                    Content = c.Content,
                    Date = c.Date,
                    Published = c.Published
                })
            };

            return Ok(ApiResponse.Ok(result));
        }

        // GET articles/{articleId}/comments/5
        [HttpGet("{articleId}/[controller]/{id}")]
        public async Task<IActionResult> Get([FromRoute]int? articleId, [FromRoute]int? id)
        {
            if (articleId == null)
                return BadRequest(ApiResponse.BadRequest($"Argument article id is null"));

            if (id == null)
                return BadRequest(ApiResponse.BadRequest($"Argument comment id is null"));

            var comment = await _commentRepository.Query().FirstOrDefaultAsync(c => c.ArticleId == articleId && c.Id == id);

            if (comment == null)
                return NotFound(ApiResponse.NotFound($"Article or Comment not found with id [{articleId},{id}]"));

            var result = new CommentModel
            {
                Id = comment.Id,
                Email = comment.Email,
                Title = comment.Title,
                Content = comment.Content,
                Date = comment.Date,
                Published = comment.Published
            };

            return Ok(ApiResponse.Ok(result));
        }

        // POST articles/5/comments
        [HttpPost("{articleId}/[controller]")]
        [ApiValidationFilter]
        public async Task<IActionResult> Post([FromRoute]int? articleId, [FromBody]CommentModel model)
        {
            if (articleId == null)
                return BadRequest(ApiResponse.BadRequest($"Argument article id is null"));

            if (model == null)
                return BadRequest(ApiResponse.BadRequest("Argument model is null"));

            var comment = new Comment
            {
                ArticleId = articleId,
                Email = model.Email,
                Title = model.Title,
                Content = model.Content,
                Date = DateTime.UtcNow,
                Published = model.Published
            };

            await _commentRepository.InsertAsync(comment);

            var result = new CommentModel
            {
                Id = comment.Id,
                Email = comment.Email,
                Title = comment.Title,
                Content = comment.Content,
                Date = comment.Date,
                Published = comment.Published
            };

            return Created($"articles/{articleId}/comments/{comment.Id}", result);
        }
    }
}