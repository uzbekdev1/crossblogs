﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using crossblog.Domain;
using crossblog.Dto;
using crossblog.Filters;
using crossblog.Model;
using crossblog.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace crossblog.Controllers
{
    [Route("[controller]")]
    public class ArticlesController : Controller
    {
        private readonly IArticleRepository _articleRepository;

        public ArticlesController(IArticleRepository articleRepository)
        {
            _articleRepository = articleRepository ?? throw new ArgumentNullException(nameof(articleRepository));
        }

        // GET articles/search
        [HttpGet("search")]
        public IActionResult Search([FromQuery]string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                return BadRequest(ApiResponse.BadRequest("Argument title is null"));

            var articles = _articleRepository.Query()
                .Where(a => a.Title.Contains(title) || a.Content.Contains(title))
                .OrderByDescending(a => a.Date)
                .Take(20);

            var result = new ArticleListModel
            {
                Articles = articles.Select(a => new ArticleModel
                {
                    Id = a.Id,
                    Title = a.Title,
                    Content = a.Content,
                    Date = a.Date,
                    Published = a.Published
                })
            };

            return Ok(ApiResponse.Ok(result));
        }

        // GET articles/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int? id)
        {
            if (id == null)
                return BadRequest(ApiResponse.BadRequest("Argument id is null"));

            var article = await _articleRepository.GetAsync(id);

            if (article == null)
                return NotFound(ApiResponse.NotFound($"Article not found with id {id}"));

            var result = new ArticleModel
            {
                Id = article.Id,
                Title = article.Title,
                Content = article.Content,
                Date = article.Date,
                Published = article.Published
            };

            return Ok(ApiResponse.Ok(result));
        }

        // POST articles
        [HttpPost]
        [ApiValidationFilter]
        public async Task<IActionResult> Post([FromBody]ArticleModel model)
        {
            if (model == null)
                return BadRequest(ApiResponse.BadRequest("Argument model is null"));

            var article = new Article
            {
                Title = model.Title,
                Content = model.Content,
                Date = model.Date,
                Published = model.Published
            };

            await _articleRepository.InsertAsync(article);

            return Created($"articles/{article.Id}", article);
        }

        // PUT articles/5
        [HttpPut("{id}")]
        [HttpPost]
        public async Task<IActionResult> Put(int? id, [FromBody]ArticleModel model)
        {
            if (id == null)
                return BadRequest(ApiResponse.BadRequest("Argument id is null"));

            if (model == null)
                return BadRequest(ApiResponse.BadRequest("Argument model is null"));

            var article = await _articleRepository.GetAsync(id);

            if (article == null)
                return NotFound(ApiResponse.NotFound($"Article not found with id {id}"));

            article.Title = model.Title;
            article.Content = model.Content;
            article.Date = DateTime.UtcNow;
            article.Published = model.Published;

            await _articleRepository.UpdateAsync(article);

            return Ok(ApiResponse.Ok(article));
        }

        // DELETE articles/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return BadRequest(ApiResponse.BadRequest("Argument id is null"));

            var article = await _articleRepository.GetAsync(id);

            if (article == null)
                return NotFound(ApiResponse.NotFound($"Article not found with id {id}"));

            await _articleRepository.DeleteAsync(article);

            return Ok(ApiResponse.Ok(article));
        }
    }
}