﻿using System.Linq;
using System.Threading.Tasks;
using crossblog.Controllers;
using crossblog.Domain;
using crossblog.Dto;
using crossblog.Model;
using crossblog.Repositories;
using crossblog.tests.Extensions;
using FizzWare.NBuilder;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace crossblog.tests.Controllers
{
    public class ArticlesControllerTests
    {
        private readonly ArticlesController _articlesController;
        private readonly Mock<IArticleRepository> _articleRepositoryMock;

        public ArticlesControllerTests()
        {
            _articleRepositoryMock = new Mock<IArticleRepository>();
            _articlesController = new ArticlesController(_articleRepositoryMock.Object);
        }

        [Fact]
        public async Task Get_NotFound()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Article>(null));

            // Act
            var result = await _articlesController.Get(1);

            // Assert
            Assert.NotNull(result);

            //result
            var objectResult = result as NotFoundObjectResult;
            Assert.NotNull(objectResult);

            //response
            var response = (ApiResponse)objectResult.Value;
            Assert.NotNull(response);
            Assert.False(response.IsSuccess);
        }

        [Fact]
        public async Task Get_ReturnsItem()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult(Builder<Article>.CreateNew().Build()));

            // Act
            var result = await _articlesController.Get(1);

            // Assert
            Assert.NotNull(result);

            //result
            var objectResult = result as OkObjectResult;
            Assert.NotNull(objectResult);

            //response
            var response = (ApiResponse)objectResult.Value;
            Assert.NotNull(response);
            Assert.True(response.IsSuccess);

            //content
            var content = response.Result as ArticleModel;
            Assert.NotNull(content);

            Assert.Equal("Title1", content.Title);
        }

        [Fact]
        public void Search_ReturnsEmptyList()
        {
            // Arrange
            var articleDbSetMock = Builder<Article>.CreateListOfSize(3).Build().ToAsyncDbSetMock();
            _articleRepositoryMock.Setup(m => m.Query()).Returns(articleDbSetMock.Object);

            // Act
            var result = _articlesController.Search("Invalid");

            // Assert
            Assert.NotNull(result);

            //result
            var objectResult = result as OkObjectResult;
            Assert.NotNull(objectResult);

            //response
            var response = (ApiResponse)objectResult.Value;
            Assert.NotNull(response);
            Assert.True(response.IsSuccess);

            //content
            var content = response.Result as ArticleListModel;
            Assert.NotNull(content);
            Assert.Empty(content.Articles);
        }

        [Fact]
        public void Search_ReturnsList()
        {
            // Arrange
            var articleDbSetMock = Builder<Article>.CreateListOfSize(3).Build().ToAsyncDbSetMock();
            _articleRepositoryMock.Setup(m => m.Query()).Returns(articleDbSetMock.Object);

            // Act
            var result = _articlesController.Search("Title");

            // Assert
            Assert.NotNull(result);

            //result
            var objectResult = result as OkObjectResult;
            Assert.NotNull(objectResult);

            //response
            var response = (ApiResponse)objectResult.Value;
            Assert.NotNull(response);
            Assert.True(response.IsSuccess);

            //content
            var content = response.Result as ArticleListModel;
            Assert.NotNull(content);
            Assert.Equal(3, content.Articles.Count());
        }
    }
}